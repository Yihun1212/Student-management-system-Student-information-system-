from django.apps import AppConfig

class CrudStudentConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'crud_student'  # <-- must match folder name
